package com.example.musicapp.Activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.musicapp.Adapter.PlayingViewPagerAdapter;
import com.example.musicapp.Adapter.SongsPlayAdapter;
import com.example.musicapp.Fragment.Fragment_Playing;
import com.example.musicapp.Fragment.Fragment_Songs_To_Play;
import com.example.musicapp.Model.Songs;
import com.example.musicapp.R;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Random;

public class PlayActivity extends AppCompatActivity {

    Toolbar toolbarPlay;
    TextView txtTimer,txtFullTimer;
    SeekBar seekBarPlay;
    ImageView imgplaying;
    ImageButton btnPre,btnShuffle,btnPlay,btnNext,btnLoop;
    ViewPager viewPagerPlay;
    Fragment_Songs_To_Play fragment_songs_to_play;
    Fragment_Playing fragment_playing;
    MediaPlayer mediaPlayer;
    int position = 0;
    boolean loop = false;
    boolean shuffle = false;
    boolean next = false;


    public static ArrayList<Songs> SongsArray = new ArrayList<>();
    public static PlayingViewPagerAdapter playingViewPagerAdapter;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);
        GetDataFromIntent();
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        init();
        eventClick();
    }

    private void eventClick()
    {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (playingViewPagerAdapter.getItem(1) != null)
                {
                    if(SongsArray.size() >0)
                    {
                        imgplaying = findViewById(R.id.imgPlayingSong);
                        Picasso.with(fragment_playing.getContext()).load(SongsArray.get(position).getSongImage()).into(imgplaying);
                        // Load hinh lai lan 1
                        handler.removeCallbacks(this);
                    }
                    else
                    {
                        handler.postDelayed(this, 300);
                    }
                }
            }
        },500);
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mediaPlayer.isPlaying())
                {
                    mediaPlayer.pause();
                    btnPlay.setImageResource(R.drawable.iconplay);
                }
                else
                {
                    mediaPlayer.start();
                    btnPlay.setImageResource(R.drawable.iconpause);
                }
                UpdateTime();
            }
        });
        btnLoop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(loop == false)
                {
                    if(shuffle == true)
                    {
                        shuffle = false;
                        btnShuffle.setImageResource(R.drawable.iconsuffle);
                    }
                    btnLoop.setImageResource(R.drawable.iconsyned);
                    loop = true;
                }
                else
                {
                    btnLoop.setImageResource(R.drawable.iconrepeat);
                    loop = false;
                }
            }
        });
        btnShuffle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (shuffle == false)
                {
                    if(loop == true)
                    {
                        loop = false;
                        btnLoop.setImageResource(R.drawable.iconrepeat);
                    }
                    btnShuffle.setImageResource(R.drawable.iconshuffled);
                    shuffle = true;
                }
                else
                {
                    shuffle = false;
                    btnShuffle.setImageResource(R.drawable.iconsuffle);
                }
            }
        });
        seekBarPlay.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mediaPlayer.seekTo(seekBar.getProgress());
            }
        });
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(SongsArray.size() >0)
                {
                    if ( mediaPlayer.isPlaying() || mediaPlayer != null)
                    {
                        mediaPlayer.stop();
                        mediaPlayer.release();
                        mediaPlayer = null;

                    }
                    if (position < (SongsArray.size()))
                    {
                        btnPlay.setImageResource(R.drawable.iconpause);
                        position++;
                        if (loop == true)
                        {
                            if (position == 0)
                            {
                                position = SongsArray.size();
                            }
                            position -= 1;
                        }
                        if (shuffle == true)
                        {
                            Random random = new Random();
                            int index = random.nextInt(SongsArray.size());
                            if (index == position)
                            {
                                position = index -1;

                            }
                            position = index;

                        }
                        if (position > SongsArray.size() -1)
                        {
                            position = 0;
                        }
                        new Playing().execute(SongsArray.get(position).getSongLink());
                        // set image
                        getSupportActionBar().setTitle(SongsArray.get(position).getSongName());


                    }
                    UpdateTime();
                }
                btnPre.setClickable(false);
                btnNext.setClickable(false);
                Handler handler1 = new Handler();
                handler1.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        btnPre.setClickable(true);
                        btnNext.setClickable(true);

                    }
                }, 4000);

            }
        });
        btnPre.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(SongsArray.size() >0)
                {
                    if ( mediaPlayer.isPlaying() || mediaPlayer != null)
                    {
                        mediaPlayer.stop();
                        mediaPlayer.release();
                        mediaPlayer = null;

                    }
                    if (position < (SongsArray.size()))
                    {
                        btnPlay.setImageResource(R.drawable.iconpause);
                        position--;
                        if (loop == true)
                        {
                            position += 1;
                        }
                        if (shuffle == true)
                        {
                            Random random = new Random();
                            int index = random.nextInt(SongsArray.size());
                            if (index == position)
                            {
                                position = index -1;

                            }
                            position = index;

                        }
                        if (position < 0)
                        {
                            position = SongsArray.size() -1;
                        }
                        new Playing().execute(SongsArray.get(position).getSongLink());
                        // set image
                        getSupportActionBar().setTitle(SongsArray.get(position).getSongName());


                    }
                    UpdateTime();
                }
                btnPre.setClickable(false);
                btnNext.setClickable(false);
                Handler handler1 = new Handler();
                handler1.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        btnPre.setClickable(true);
                        btnNext.setClickable(true);

                    }
                }, 4000);

            }
        });
    }

    private void GetDataFromIntent()
    {
        Intent intent = getIntent();
        SongsArray.clear();
        if (intent != null)
        {
            if (intent.hasExtra("Songs"))
            {
                Songs songs = intent.getParcelableExtra("Songs");
                SongsArray.add(songs);
            }
            if (intent.hasExtra("AllSongs"))
            {
                ArrayList<Songs> SongsArrayList = intent.getParcelableArrayListExtra("AllSongs");
                SongsArray = SongsArrayList;
            }
        }

    }

    private void init() {
        toolbarPlay = findViewById(R.id.playToolBar);
        txtTimer = findViewById(R.id.txtTimer);
        txtFullTimer = findViewById(R.id.txtFullTimer);
        seekBarPlay = findViewById(R.id.playSeekBar);
        btnPre = findViewById(R.id.imgPre);
        btnShuffle = findViewById(R.id.imgShuffle);
        btnLoop = findViewById(R.id.imgLoop);
        btnNext = findViewById(R.id.imgNext);
        btnPlay = findViewById(R.id.imgPlay);
        viewPagerPlay = findViewById(R.id.playViewPager);
        imgplaying = findViewById(R.id.imgPlayingSong);
        setSupportActionBar(toolbarPlay);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarPlay.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                mediaPlayer.stop();
                SongsArray.clear();
            }
        });
        toolbarPlay.setTitleTextColor(Color.BLUE);

        fragment_songs_to_play = new Fragment_Songs_To_Play();
        fragment_playing = new Fragment_Playing();
        playingViewPagerAdapter = new PlayingViewPagerAdapter(getSupportFragmentManager());
        playingViewPagerAdapter.AddFragment(fragment_playing);
        playingViewPagerAdapter.AddFragment(fragment_songs_to_play);
        viewPagerPlay.setAdapter(playingViewPagerAdapter);

        fragment_playing = (Fragment_Playing) playingViewPagerAdapter.getItem(0);

        if (SongsArray.size() > 0) {
            getSupportActionBar().setTitle(SongsArray.get(0).getSongName());
            new Playing().execute(SongsArray.get(0).getSongLink());
            btnPlay.setImageResource(R.drawable.iconpause);


        }

    }
    class Playing extends AsyncTask<String, Void, String>{

        @Override
        protected String doInBackground(String... strings) {
            return strings[0];
        }

        @Override
        protected void onPostExecute(String song) {
            super.onPostExecute(song);
            try {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mediaPlayer.stop();
                    mediaPlayer.reset();
                }
            });

                mediaPlayer.setDataSource(song);
                mediaPlayer.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }
            mediaPlayer.start();
            TimeSong();
            UpdateTime();
        }
    }

    private void TimeSong()
    {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("mm:ss");
        txtFullTimer.setText(simpleDateFormat.format(mediaPlayer.getDuration()));
        seekBarPlay.setMax(mediaPlayer.getDuration());
    }
    private  void UpdateTime()
    {
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if( mediaPlayer != null)
                {
                    seekBarPlay.setProgress(mediaPlayer.getCurrentPosition());
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("mm:ss");
                    txtTimer.setText(simpleDateFormat.format(mediaPlayer.getCurrentPosition()));
                    handler.postDelayed(this, 300);
                    mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer mp) {
                            next = true;
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }
            }
        },3000);
        final Handler handler1 = new Handler();
        handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(next == true)
                {
                    if(SongsArray.size() >0)
                    {
                        if ( mediaPlayer.isPlaying() || mediaPlayer != null)
                        {
                            mediaPlayer.stop();
                            mediaPlayer.release();
                            mediaPlayer = null;

                        }
                        if (position < (SongsArray.size()))
                        {
                            btnPlay.setImageResource(R.drawable.iconpause);
                            position++;
                            if (loop == true)
                            {
                                if (position == 0)
                                {
                                    position = SongsArray.size();
                                }
                                position -= 1;
                            }
                            if (shuffle == true)
                            {
                                Random random = new Random();
                                int index = random.nextInt(SongsArray.size());
                                if (index == position)
                                {
                                    position = index -1;

                                }
                                position = index;

                            }
                            if (position > SongsArray.size() -1)
                            {
                                position = 0;
                            }
                            new Playing().execute(SongsArray.get(position).getSongLink());
                            // set image
                            getSupportActionBar().setTitle(SongsArray.get(position).getSongName());


                        }
                    }
                    btnPre.setClickable(false);
                    btnNext.setClickable(false);
                    Handler handler1 = new Handler();
                    handler1.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            btnPre.setClickable(true);
                            btnNext.setClickable(true);

                        }
                    }, 2000);
                    next = false;
                    handler1.removeCallbacks(this);
                }
                else
                {
                    handler1.postDelayed(this,1000);
                }
            }
        },1000);
    }
}
