package com.example.musicapp.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicapp.Activity.PlayActivity;
import com.example.musicapp.Model.Songs;
import com.example.musicapp.R;

import java.util.ArrayList;
import java.util.List;

public class ListSongsAdapter extends RecyclerView.Adapter<ListSongsAdapter.ViewHolder>{
    Context context;
    ArrayList<Songs> SongsArray;

    public ListSongsAdapter(Context context, ArrayList<Songs> songsArray) {
        this.context = context;
        SongsArray = songsArray;
    }

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.list_songs_line,parent,false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Songs songs = SongsArray.get(position);
        holder.singerName.setText(songs.getSingerName());
        holder.songName.setText(songs.getSongName());
        holder.index.setText(position+1+"|");
    }

    @Override
    public int getItemCount() {
        return SongsArray.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView index,songName,singerName;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            singerName = itemView.findViewById(R.id.txtSingerName);
            songName = itemView.findViewById(R.id.txtSongName);
            index = itemView.findViewById(R.id.listSongsIndex);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, PlayActivity.class);
                    intent.putExtra("Songs",SongsArray.get(getPosition()));
                    context.startActivity(intent);
                }
            });
        }
    }
}
