package com.example.musicapp.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicapp.Activity.PlayActivity;
import com.example.musicapp.Model.Songs;
import com.example.musicapp.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class SearchingAdapter extends RecyclerView.Adapter<SearchingAdapter.ViewHolder>{
    Context context;
    ArrayList<Songs> songsArrayList;

    public SearchingAdapter(Context context, ArrayList<Songs> songsArrayList) {
        this.context = context;
        this.songsArrayList = songsArrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.item_search,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Songs songs = songsArrayList.get(position);
        holder.txtSong.setText(songs.getSongName());
        holder.txtSinger.setText(songs.getSingerName());
        Picasso.with(context).load(songs.getSongImage()).into(holder.imgSearchImg);
    }

    @Override
    public int getItemCount() {
        return songsArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtSong,txtSinger;
        ImageView imgSearchImg;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtSong = itemView.findViewById(R.id.txtSongNameSearch);
            txtSinger = itemView.findViewById(R.id.txtSingerSearch);
            imgSearchImg = itemView.findViewById(R.id.imgSearch);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, PlayActivity.class);
                    intent.putExtra("Songs",songsArrayList.get(getPosition()));
                    context.startActivity(intent);
                }
            });
        }
    }
}
