package com.example.musicapp.Adapter;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicapp.Model.Songs;
import com.example.musicapp.R;

import java.util.ArrayList;

public class SongsPlayAdapter extends RecyclerView.Adapter<SongsPlayAdapter.ViewHolder> {

    Context context;
    ArrayList<Songs> SongsArrayList;

    public SongsPlayAdapter(Context context, ArrayList<Songs> songsArrayList) {
        this.context = context;
        SongsArrayList = songsArrayList;
    }

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.songs_play_item,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Songs songs = SongsArrayList.get(position);
        holder.txtSingerName.setText(songs.getSingerName());
        holder.txtNameSong.setText(songs.getSongName());
        holder.txtIndex.setText(position+1+"|");
    }

    @Override
    public int getItemCount() {
        return SongsArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder
    {
        TextView txtIndex,txtNameSong,txtSingerName;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtIndex = itemView.findViewById(R.id.txtPlayIndex);
            txtNameSong = itemView.findViewById(R.id.txtSongNamePlay);
            txtSingerName = itemView.findViewById(R.id.txtSingerNamePlay);
        }
    }
}
