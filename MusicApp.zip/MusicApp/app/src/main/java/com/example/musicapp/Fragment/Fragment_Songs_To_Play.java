package com.example.musicapp.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.musicapp.Activity.PlayActivity;
import com.example.musicapp.Adapter.SongsPlayAdapter;
import com.example.musicapp.R;

import java.util.zip.Inflater;

public class Fragment_Songs_To_Play extends Fragment {

    View view;
    RecyclerView recyclerViewSongsPlay;
    SongsPlayAdapter songsPlayAdapter;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_songs_to_play, container, false);
        recyclerViewSongsPlay = view.findViewById(R.id.recyclerViewPlaySongs);
        if (PlayActivity.SongsArray.size()>0)
        {
            songsPlayAdapter = new SongsPlayAdapter(getActivity(), PlayActivity.SongsArray);
            recyclerViewSongsPlay.setLayoutManager(new LinearLayoutManager(getActivity()));
            recyclerViewSongsPlay.setAdapter(songsPlayAdapter);
        }


        return view;
    }
}
