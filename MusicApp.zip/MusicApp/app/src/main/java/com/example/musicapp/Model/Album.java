package com.example.musicapp.Model;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Album implements Serializable {

@SerializedName("AlbumID")
@Expose
private String albumID;
@SerializedName("AlbumName")
@Expose
private String albumName;
@SerializedName("AlbumImage")
@Expose
private String albumImage;
@SerializedName("SongID")
@Expose
private String songID;
@SerializedName("SongName")
@Expose
private String songName;
@SerializedName("SongImage")
@Expose
private String songImage;

public String getAlbumID() {
return albumID;
}

public void setAlbumID(String albumID) {
this.albumID = albumID;
}

public String getAlbumName() {
return albumName;
}

public void setAlbumName(String albumName) {
this.albumName = albumName;
}

public String getAlbumImage() {
return albumImage;
}

public void setAlbumImage(String albumImage) {
this.albumImage = albumImage;
}

public String getSongID() {
return songID;
}

public void setSongID(String songID) {
this.songID = songID;
}

public String getSongName() {
return songName;
}

public void setSongName(String songName) {
this.songName = songName;
}

public String getSongImage() {
return songImage;
}

public void setSongImage(String songImage) {
this.songImage = songImage;
}

}