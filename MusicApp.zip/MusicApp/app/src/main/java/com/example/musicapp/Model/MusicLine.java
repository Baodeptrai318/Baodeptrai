package com.example.musicapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class MusicLine implements Serializable {

@SerializedName("MusicLine")
@Expose
private String musicLine;
@SerializedName("MusicImage")
@Expose
private String musicImage;

public String getMusicLine() {
return musicLine;
}

public void setMusicLine(String musicLine) {
this.musicLine = musicLine;
}

public String getMusicImage() {
return musicImage;
}

public void setMusicImage(String musicImage) {
this.musicImage = musicImage;
}

}