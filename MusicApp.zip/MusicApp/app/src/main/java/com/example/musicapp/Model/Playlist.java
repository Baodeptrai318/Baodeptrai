package com.example.musicapp.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class Playlist implements Serializable {

@SerializedName("PlayListID")
@Expose
private String playListID;
@SerializedName("PlayListName")
@Expose
private String playListName;
@SerializedName("BackGroundPL")
@Expose
private String backGroundPL;
@SerializedName("IconPL")
@Expose
private String iconPL;

public String getPlayListID() {
return playListID;
}

public void setPlayListID(String playListID) {
this.playListID = playListID;
}

public String getPlayListName() {
return playListName;
}

public void setPlayListName(String playListName) {
this.playListName = playListName;
}

public String getBackGroundPL() {
return backGroundPL;
}

public void setBackGroundPL(String backGroundPL) {
this.backGroundPL = backGroundPL;
}

public String getIconPL() {
return iconPL;
}

public void setIconPL(String iconPL) {
this.iconPL = iconPL;
}

}