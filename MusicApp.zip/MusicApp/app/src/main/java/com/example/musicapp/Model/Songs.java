package com.example.musicapp.Model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
        import com.google.gson.annotations.SerializedName;

public class Songs implements Parcelable {

    @SerializedName("SongID")
    @Expose
    private String songID;
    @SerializedName("AlbumID")
    @Expose
    private String albumID;
    @SerializedName("MusicID")
    @Expose
    private String musicID;
    @SerializedName("PlayListID")
    @Expose
    private String playListID;
    @SerializedName("SongName")
    @Expose
    private String songName;
    @SerializedName("SongImage")
    @Expose
    private String songImage;
    @SerializedName("SingerName")
    @Expose
    private String singerName;
    @SerializedName("SongLink")
    @Expose
    private String songLink;

    protected Songs(Parcel in) {
        songID = in.readString();
        albumID = in.readString();
        musicID = in.readString();
        playListID = in.readString();
        songName = in.readString();
        songImage = in.readString();
        singerName = in.readString();
        songLink = in.readString();
    }

    public static final Creator<Songs> CREATOR = new Creator<Songs>() {
        @Override
        public Songs createFromParcel(Parcel in) {
            return new Songs(in);
        }

        @Override
        public Songs[] newArray(int size) {
            return new Songs[size];
        }
    };

    public String getSongID() {
        return songID;
    }

    public void setSongID(String songID) {
        this.songID = songID;
    }

    public String getAlbumID() {
        return albumID;
    }

    public void setAlbumID(String albumID) {
        this.albumID = albumID;
    }

    public String getMusicID() {
        return musicID;
    }

    public void setMusicID(String musicID) {
        this.musicID = musicID;
    }

    public String getPlayListID() {
        return playListID;
    }

    public void setPlayListID(String playListID) {
        this.playListID = playListID;
    }

    public String getSongName() {
        return songName;
    }

    public void setSongName(String songName) {
        this.songName = songName;
    }

    public String getSongImage() {
        return songImage;
    }

    public void setSongImage(String songImage) {
        this.songImage = songImage;
    }

    public String getSingerName() {
        return singerName;
    }

    public void setSingerName(String singerName) {
        this.singerName = singerName;
    }

    public String getSongLink() {
        return songLink;
    }

    public void setSongLink(String songLink) {
        this.songLink = songLink;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(songID);
        dest.writeString(albumID);
        dest.writeString(musicID);
        dest.writeString(playListID);
        dest.writeString(songName);
        dest.writeString(songImage);
        dest.writeString(singerName);
        dest.writeString(songLink);
    }
}