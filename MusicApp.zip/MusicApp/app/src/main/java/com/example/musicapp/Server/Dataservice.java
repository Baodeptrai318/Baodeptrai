package com.example.musicapp.Server;

import com.example.musicapp.Model.Album;
import com.example.musicapp.Model.MusicLine;
import com.example.musicapp.Model.Playlist;
import com.example.musicapp.Model.Songs;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Dataservice {

    @GET("Albumbanner.php")
    Call<List<Album>> GetDataBanner();

    @GET("Playlist.php")
    Call<List<Playlist>> GetPlaylistData();

    @FormUrlEncoded
    @POST("SongOfAlbum.php")
    Call<List<Songs>> GetSongsFromAlbum(@Field("AlbumID") String AlbumID);

    @FormUrlEncoded
    @POST("Searching.php")
    Call<List<Songs>> GetSearchResult(@Field("Keyword") String Keyword);

    @GET("MusicLine.php")
    Call<List<MusicLine>> GetMusicLine();

    @FormUrlEncoded
    @POST("SongOfAlbum.php")
    Call<List<Songs>> GetSongsFromPlaylist(@Field("PlayListID") String PlayListID);
}
